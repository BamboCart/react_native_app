'use strict';

const Constants = {
    URL: {
        root: 'http://beostore.io'
    },
    Keys: {
        ConsumerKey: 'ck_223378193c406cd3fa5124fb4532a0cc7c22bf66',
	    ConsumerSecret: 'cs_0eaf41aedaf0bd40d074cf551cd53842e2f83853'
    }
}

module.exports = Constants;
