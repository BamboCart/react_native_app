import { createStore } from 'redux'
import Auth from '../Reducer'

const store = createStore(Auth)
export default store