// export const ADD_TODO = 'ADD_TODO'
// export const TOGGLE_TODO = 'TOGGLE_TODO'
// export const SET_VISIBILITY_FILTER = 'SET_VISIBILITY_FILTER'


export const LOGINUSER = 'LOGINUSER'
export const LOGOUTUSER = 'LOGOUTUSER'
export const CART = 'CART'
export const CART_ADD = 'CART_ADD'
export const CART_DELETE = 'CART_DELETE'
export const CART_QE = 'CART_QE'
export const CartTotal = 'CartTotal'