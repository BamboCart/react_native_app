import ButtonC from './Button'
import CarC from './Categories'
import CheckoutCard from './CheckoutCard'
import GButton from './GButton'
import HeaderC from './header'
import ICard from './ICard'
import SearchC from './Search'
import TCarC from './TCard'

export { ButtonC,CarC,CheckoutCard,GButton,HeaderC,ICard,SearchC,TCarC }

